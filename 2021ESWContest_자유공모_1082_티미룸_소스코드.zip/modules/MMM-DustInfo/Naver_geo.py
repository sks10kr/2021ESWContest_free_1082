import requests
import pandas as pd
import json
from bs4 import BeautifulSoup
from haversine import haversine
import firebase_admin
from firebase_admin import credentials
from firebase_admin import db

station_data = pd.read_excel("/home/pi/MagicMirror/modules/MMM-DustInfo/station_list.xlsx")
location_data = pd.read_excel("/home/pi/MagicMirror/modules/MMM-DustInfo/location.xlsx")
location_data = location_data.values.tolist()

def GPS():
    cred = credentials.Certificate('/home/pi/MagicMirror/modules/MMM-DustInfo/myKey.json')
    firebase_admin.initialize_app(cred,{
        'databaseURL' : 'https://help-airman-project-default-rtdb.firebaseio.com/'
    })

    # ref = db.reference('out/latitude')
    # lat = ref.get()
    # ref = db.reference('out/longitude')
    # long = ref.get()
    lat = 37.631526
    long = 127.076377

    global curr_Loc
    curr_Loc = [[lat, long]]
    # print(curr_Loc)

def search_station():
    GPS()
    station_Loc = location_data
    
    min = 10000
    for i in range(489):
        distance = haversine((station_Loc[i][1], station_Loc[i][2]), curr_Loc[0], unit = 'km')
        if distance < min:
            min = distance
            globals()['station_index'] = i

def Dust_info():
    search_station()
    city = station_data.loc[station_index]['측정소명']
    key = "mr81qR0Ed0RG4%2FUFpmXXLO0c7AO3HI6PC%2BVFgy%2BMO1yZ%2F7ciBAJejaPZ%2FmHi%2F30D4CYg7DKkGwpxHXTgHQDTSQ%3D%3D"
    url = "http://apis.data.go.kr/B552584/ArpltnInforInqireSvc/getMsrstnAcctoRltmMesureDnsty?stationName={}&dataTerm=month&pageNo=1&numOfRows=100&returnType=xml&serviceKey={}&ver=1.0".format(city, key)
    res = requests.get(url)
    res.raise_for_status()
    content = BeautifulSoup(res.text, "lxml")

    dust_pm10 = content.item
    dust_pm25 = content.item

    pm10 = dust_pm10.pm10value
    pm25 = dust_pm25.pm25value
    check_pm10 = pm10.get_text()
    check_pm25 = pm25.get_text()

    if check_pm10 == '-':
        dust_pm10 = dust_pm10.next_sibling
        dust_pm10 = dust_pm10.next_sibling
    if check_pm25 == '-':
        dust_pm25 = dust_pm25.next_sibling
        dust_pm25 = dust_pm25.next_sibling

    pm10 = dust_pm10.pm10value
    pm10 = int(pm10.get_text())

    pm25 = dust_pm25.pm25value
    pm25 = int(pm25.get_text())

    data = {
        "station" : station_data.loc[station_index]['측정소명'],
        "pm10" : pm10,
        "pm25" : pm25
        }
    data_json = json.dumps(data)
    print (data_json)

Dust_info()