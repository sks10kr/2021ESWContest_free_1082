const spawn = require('child_process').spawn;

const result = spawn('python', ['Naver_geo.py']);

var abc = [];

// stdout의 'data'이벤트리스너로 실행결과를 받는다.
result.stdout.on('data', function(data) {
  console.log(data.toString());
  abc = data.toString();
  abc = JSON.parse(abc);
});

result.on('close', (code) => {
  console.log(abc.station);
})