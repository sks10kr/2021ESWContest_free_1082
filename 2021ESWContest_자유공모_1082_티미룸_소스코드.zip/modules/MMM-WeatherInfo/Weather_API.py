import requests
import requests
import pandas as pd
import json
from bs4 import BeautifulSoup
from haversine import haversine
import datetime
import firebase_admin
from firebase_admin import credentials
from firebase_admin import db

# 마지막 인덱스 값은 3771
weather_station_data = pd.read_excel("/home/pi/MagicMirror/modules/MMM-WeatherInfo/weather_station.xlsx")

def GPS():
    cred = credentials.Certificate('/home/pi/MagicMirror/modules/MMM-WeatherInfo/myKey.json')
    firebase_admin.initialize_app(cred,{
        'databaseURL' : 'https://help-airman-project-default-rtdb.firebaseio.com/'
    })

    # ref = db.reference('out/latitude') #db 위치 지정
    # lat = ref.get()
    # ref = db.reference('out/longitude') #db 위치 지정
    # long = ref.get()

    lat = 37.631526
    long = 127.076377

    global curr_Loc
    curr_Loc = [lat, long]

def search_station():
    GPS()
    
    min = 10000
    for i in range(3771):

        distance = haversine((weather_station_data.loc[i]['위도(초/100)'], weather_station_data.loc[i]['경도(초/100)']), (curr_Loc[0], curr_Loc[1]), unit = 'km')
        if distance < min:
            min = distance
            globals()['station_index'] = i
    # print(station_index)

def Weather_info():
    search_station()

    city_nx = int(weather_station_data.loc[station_index]['격자 X'])
    city_ny = int(weather_station_data.loc[station_index]['격자 Y'])
    
    current_time = datetime.datetime.now()
    year = current_time.year
    month = current_time.month
    day = current_time.day
    hour = current_time.hour

    global curr_date
    if(day < 10):
        if (hour >= 0 and hour < 6):
            day = day - 1
            day = "0" + str(day)
        else:
            day = "0" + str(day)
    else:
        if (hour >= 0 and hour < 6):
            day = day - 1
            day = str(day)
        else:
            day = str(day)

    if(month < 10):
        month = "0" + str(month)
        curr_date = str(year) + month + day
    else:
        month = str(month)
        curr_date = str(year) + str(month) + day
    
    global curr_time
    if(hour >= 0 and hour < 3):
        curr_time = "2000"

    elif(hour >= 3 and hour < 6):
        curr_time = "2300"
    
    elif(hour >= 6 and hour < 9):
        curr_time = "0200"
    
    elif(hour >=9 and hour < 12):
        curr_time = "0500"
    
    elif(hour >= 12 and hour < 15):
        curr_time = "0800"
    
    elif(hour >= 15 and hour < 18):
        curr_time = "1100"

    elif(hour >= 18 and hour < 21):
        curr_time = "1400"

    elif(hour >= 21):
        curr_time = "1700"

    key = "mr81qR0Ed0RG4%2FUFpmXXLO0c7AO3HI6PC%2BVFgy%2BMO1yZ%2F7ciBAJejaPZ%2FmHi%2F30D4CYg7DKkGwpxHXTgHQDTSQ%3D%3D"
    url = "http://apis.data.go.kr/1360000/VilageFcstInfoService/getVilageFcst?serviceKey={}&numOfRows=10&pageNo=1&base_date={}&base_time={}&nx={}&ny={}".format(key, curr_date, curr_time, city_nx, city_ny)
    res = requests.get(url)
    res.raise_for_status()
    content = BeautifulSoup(res.text, "lxml")

    prob = content.item
    rain = prob.next_sibling
    # print(rain.category)

    dummy1 = rain.next_sibling
    global humid
    if (dummy1.category.get_text() == "REH"):
        humid = rain.next_sibling
    else:
        humid = dummy1.next_sibling
    
    dummy2 = humid.next_sibling
    global sky
    if (dummy2.category.get_text() == "SKY"):
        sky = humid.next_sibling
    else:
        sky = dummy2.next_sibling
    
    temp = sky.next_sibling

    #강수 확률
    prob_data = prob.fcstvalue
    check_prob = prob_data.get_text()

    if check_prob == '-':
        prob = prob.next_sibling
        prob = prob.next_sibling

    prob_data = prob.fcstvalue
    prob_data = int(prob_data.get_text())
    
    #비
    rain_data = rain.fcstvalue
    check_rain = rain_data.get_text()

    if check_rain == '-':
        rain = rain.next_sibling
        rain = rain.next_sibling

    rain_data = rain.fcstvalue
    rain_data = int(rain_data.get_text())

    #습도
    humid_data = humid.fcstvalue
    check_humid = humid_data.get_text()

    if check_humid == '-':
        humid = humid.next_sibling
        humid = humid.next_sibling

    humid_data = humid.fcstvalue
    humid_data = int(humid_data.get_text())

    #구름
    sky_data = sky.fcstvalue
    check_sky = sky_data.get_text()

    if check_sky == '-':
        sky = sky.next_sibling
        sky = sky.next_sibling

    sky_data = sky.fcstvalue
    sky_data = int(sky_data.get_text())

    #온도
    temp_data = temp.fcstvalue
    check_temp = temp_data.get_text()

    if check_temp == '-':
        temp = temp.next_sibling
        temp = temp.next_sibling

    temp_data = temp.fcstvalue
    temp_data = int(temp_data.get_text())

    data = {
        "prob" : prob_data,
        "rain" : rain_data,
        "humid" : humid_data,
        "sky" : sky_data,
        "temp" : temp_data
        }
    data_json = json.dumps(data)
    print (data_json)

Weather_info()