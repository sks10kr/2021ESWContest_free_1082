Module.register("MMM-WeatherInfo", {
	defaults: {
		updateInterval: 600000,

	},

	requiresVersion: "2.1.0", // Required version of MagicMirror

	start: function () {
        // Log.info("Starting module: " + this.name);
        // requiresVersion: "2.1.0";
        // this.loaded = false;
        this.scheduleUpdate();

    },

    getStyles: function() {
        return["MMM-WeatherInfo.css", "font-awesome.css"];
    },

	scheduleUpdate: function () {
        setInterval(() => {
            this.getData();
        }, this.config.updateInterval);
        this.getData();
    },

	
	getData: function() {
		console.log('GET_TEXT_DATA', this.config)
		this.sendSocketNotification('GET_TEXT_DATA', this.config);
	},

	socketNotificationReceived: function (notification, payload) {
		if (notification === "TEXT_RESULT") {
			this.textDataRecived = payload;
			this.loaded = true;
	   } 
	   this.updateDom();
	},


	getDom: function () {
        var wrapper = document.createElement("div");

        if (!this.loaded) {
            wrapper.innerHTML = "LOADING";
            return wrapper;
        }
        if (this.loaded) {

            var table = document.createElement('td');

            var space1 = document.createElement('tr');
            var space2 = document.createElement('tr');
            var space3 = document.createElement('tr');


            var weatherIcon = document.createElement("tr");
            if (this.textDataRecived.rain == 1 || this.textDataRecived.rain == 4 || this.textDataRecived.rain == 5) {
                Icon_weather = "fas fa-cloud-rain";
                weatherIcon.id = 'rain'
            }
            else if (this.textDataRecived.rain == 2 || this.textDataRecived.rain == 3 || this.textDataRecived.rain == 6 || this.textDataRecived.rain == 7) {
                Icon_weather = "far fa-snowflake"
                weatherIcon.id = 'snow'
            }
            else if (this.textDataRecived.rain == 0 && this.textDataRecived.sky == 1){
                Icon_weather = "far fa-sun"
                weatherIcon.id = 'sunny'
            }
            else if (this.textDataRecived.rain == 0 && (this.textDataRecived.sky == 3 || this.textDataRecived.sky == 4)) {
                Icon_weather = "fas fa-cloud"
                weatherIcon.id = 'cloud'
            }
            weatherIcon.className = Icon_weather;


            var tempData = document.createElement('span');
            tempData.className = "small";
            tempData.innerHTML = this.textDataRecived.temp +"°C";


            var humidIcon = document.createElement("tr");
            humidIcon.className = "fa fa-tint";
            humidIcon.id = "humid1"
            var humidData = document.createElement("span");
            humidData.className = "medium";
            humidData.innerHTML = "습도: " + this.textDataRecived.humid +"%";

            var probIcon = document.createElement("tr");
            probIcon.className = "fa fa-umbrella";
            var probData = document.createElement("span");
            probData.className = "medium";
            probData.innerHTML = "강수 확률: " + this.textDataRecived.prob + "%";


            table.appendChild(space1);
            table.appendChild(space2);
            table.appendChild(space3);

			space1.appendChild(weatherIcon);
            weatherIcon.appendChild(tempData);

            space2.appendChild(probIcon);
            probIcon.appendChild(probData);

            space3.appendChild(humidIcon);
            humidIcon.appendChild(humidData);
            
            wrapper.appendChild(table);
        }
        return wrapper;
    },
	
});
