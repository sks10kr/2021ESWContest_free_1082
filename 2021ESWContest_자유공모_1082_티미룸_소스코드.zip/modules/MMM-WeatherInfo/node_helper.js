const spawn = require('child_process').spawn;
const NodeHelper = require("node_helper");

var self;

module.exports = NodeHelper.create({

    start: function () {
        self = this;
        console.log("Starting node_helper for: " + this.name);
    },

    getData: function () {
        const result = spawn('python', ['/home/pi/MagicMirror/modules/MMM-WeatherInfo/Weather_API.py']);

		result.stdout.on('data', function(data) {
			console.log(data.toString());
			recivedData = data.toString();
			recivedData = JSON.parse(recivedData);

			prob = recivedData.prob
			rain = recivedData.rain
            humid = recivedData.humid
            sky = recivedData.sky
            temp = recivedData.temp

			var recivedData = {
                prob,
                rain,
                humid,
                sky,
                temp
            }

			self.sendSocketNotification('TEXT_RESULT', recivedData);
		  });
		  
		  process.on('exit', function() {
			if (x) {
			  x.kill();
			}
		  });
    },

    socketNotificationReceived: function (notification, payload) {

        if (notification === 'GET_TEXT_DATA') {
            self.getData();
        }
    },
});