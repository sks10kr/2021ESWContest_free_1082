const spawn = require('child_process').spawn;
const NodeHelper = require("node_helper");
require('date-utils');

var self;

module.exports = NodeHelper.create({

    start: function () {
        self = this;
        console.log("Starting node_helper for: " + this.name);
    },

    getData: function () {

        const result = spawn('python', ['/home/pi/MagicMirror/modules/MMM-Chart/Dust_Db.py']);

        result.stdout.on('data', function(data) {
			// console.log(data.toString());
			recivedData = data.toString();
			recivedData = JSON.parse(recivedData);

			pm10 = recivedData.pm10
			pm25 = recivedData.pm25

            var newDate = new Date();
            var time = newDate.toFormat('HH24:MI');

			var recivedData = {
                time,
                pm10,
                pm25,
            }
            console.log(recivedData);

			self.sendSocketNotification('TEXT_RESULT', recivedData);
		  });
		  
		  process.on('exit', function() {
			if (x) {
			  x.kill();
			}
		  });
    },

    socketNotificationReceived: function (notification, payload) {
        if (notification === 'GET_TEXT_DATA') {
            self.getData();
        }
    },
});