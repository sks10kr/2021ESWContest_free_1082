const spawn = require('child_process').spawn;
const NodeHelper = require("node_helper");

var self;

module.exports = NodeHelper.create({

    start: function () {
        self = this;
        console.log("Starting node_helper for: " + this.name);
    },

    getData: function () {
        const result = spawn('python', ['/home/pi/MagicMirror/modules/MMM-Temp/Temp_Db.py']);

		result.stdout.on('data', function(data) {
			// console.log(data.toString());
			recivedData = data.toString();
			recivedData = JSON.parse(recivedData);

			temp = recivedData.temp
			humid = recivedData.humid

			var recivedData = {
                temp,
                humid
            }

			self.sendSocketNotification('TEXT_RESULT', recivedData);
		  });
		  
		  process.on('exit', function() {
			if (x) {
			  x.kill();
			}
		  });
    },

    

    socketNotificationReceived: function (notification, payload) {

        if (notification === 'GET_TEXT_DATA') {
            self.getData();
        }
    },
});