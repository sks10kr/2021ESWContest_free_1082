Module.register("MMM-Temp", {
	defaults: {
		updateInterval: 10000,

	},

	requiresVersion: "2.1.0", // Required version of MagicMirror

	start: function () {
        // Log.info("Starting module: " + this.name);
        // requiresVersion: "2.1.0";
        // this.loaded = false;
        this.scheduleUpdate();

    },

    getStyles: function() {
        return["MMM-Temp.css", "font-awesome.css"];
    },

	scheduleUpdate: function () {
        setInterval(() => {
            this.getData();
        }, this.config.updateInterval);
        this.getData();
    },

	
	getData: function() {
		// console.log('GET_TEXT_DATA', this.config)
		this.sendSocketNotification('GET_TEXT_DATA', this.config);
	},

	socketNotificationReceived: function (notification, payload) {
		if (notification === "TEXT_RESULT") {
			this.textDataRecived = payload;
			this.loaded = true;
	   } 
	   this.updateDom();
	},


	getDom: function () {
        var wrapper = document.createElement("div");

        if (!this.loaded) {
            wrapper.innerHTML = "LOADING";
            return wrapper;
        }
        if (this.loaded) {

            var table = document.createElement('td');

            var space1 = document.createElement('tr');
            var space2 = document.createElement('tr');

            var tempIcon = document.createElement("tr");
            tempIcon.className = "fa fa-thermometer-three-quarters";
            tempIcon.id = "temp";
            var tempData = document.createElement('span');
            tempData.className = "small";
            tempData.innerHTML = "온도: " + this.textDataRecived.temp +"°C";

            var humidIcon = document.createElement("tr");
            humidIcon.className = "fa fa-tint";
            humidIcon.id = "humid"
            var humidData = document.createElement("span");
            humidData.className = "medium";
            humidData.innerHTML = "습도: " + this.textDataRecived.humid +"%";


            table.appendChild(space1);
            table.appendChild(space2);

            space1.appendChild(tempIcon);
            tempIcon.appendChild(tempData);
            
            space2.appendChild(humidIcon);
            humidIcon.appendChild(humidData);
            
            wrapper.appendChild(table);
        }
        return wrapper;
    },
	
});
