import firebase_admin
from firebase_admin import credentials
from firebase_admin import db
import json

#Firebase database 인증 및 앱 초기화
cred = credentials.Certificate('/home/pi/MagicMirror/modules/MMM-Temp/myKey.json')
firebase_admin.initialize_app(cred,{
    'databaseURL' : 'https://help-airman-project-default-rtdb.firebaseio.com/'
})

ref = db.reference('in/temp') #db 위치 지정
temp_data = ref.get()

ref = db.reference('in/hum') #db 위치 지정
humid_data = ref.get()

data = {
    "temp" : temp_data,
    "humid" : humid_data,
    }
    
data_json = json.dumps(data)
print (data_json)

