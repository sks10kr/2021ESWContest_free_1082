Module.register("MMM-Dust", {
	defaults: {
		updateInterval: 3000,

	},

	requiresVersion: "2.1.0", // Required version of MagicMirror

	start: function () {
        // Log.info("Starting module: " + this.name);
        // requiresVersion: "2.1.0";
        // this.loaded = false;
        this.scheduleUpdate();

    },

    getStyles: function() {
        return["MMM-Dust.css"];
    },

	scheduleUpdate: function () {
        setInterval(() => {
            this.getData();
        }, this.config.updateInterval);
        this.getData();
    },

	
	getData: function() {
		// console.log('GET_TEXT_DATA', this.config)
		this.sendSocketNotification('GET_TEXT_DATA', this.config);
	},

	socketNotificationReceived: function (notification, payload) {
		if (notification === "TEXT_RESULT") {
			this.textDataRecived = payload;
			this.loaded = true;
	   } 
	   this.updateDom();
	},


	getDom: function () {
        var wrapper = document.createElement("div");

        if (!this.loaded) {
            wrapper.innerHTML = "LOADING";
            return wrapper;
        }
        if (this.loaded) {

            var table = document.createElement('td');

            var space1 = document.createElement('tr');
            var space2 = document.createElement('tr');
            var space3 = document.createElement('tr');
            
            var pm10Icon = document.createElement("tr");
            if (this.textDataRecived.pm10 <= 30) {
                Icon_pm10 = "fa fa-smile-o";
                pm10Icon.id = 'smile'
            }
            else if (this.textDataRecived.pm10 > 30 && this.textDataRecived.pm10 <= 80) {
                Icon_pm10 = "fa fa-meh-o"
                pm10Icon.id = 'meh'
            }
            else {
                Icon_pm10 = "fa fa-frown-o"
                pm10Icon.id = 'frown'
            }
            pm10Icon.className = Icon_pm10;
            var pm10Data = document.createElement('span');
            pm10Data.className = "medium";
            pm10Data.innerHTML = "PM10: " + this.textDataRecived.pm10 +"㎍/㎥";

            var pm25Icon = document.createElement("tr");
		    if (this.textDataRecived.pm25 <= 15) {
                Icon_pm25 = "fa fa-smile-o";
                pm25Icon.id = 'smile';
            }
            else if (this.textDataRecived.pm25 > 15 && this.textDataRecived.pm25 <= 35) {
                Icon_pm25 = "fa fa-meh-o"
                pm25Icon.id = 'meh';
            }
            else {
                Icon_pm25 = "fa fa-frown-o"
                pm25Icon.id = 'frown';
            }
            pm25Icon.className = Icon_pm25;
            var pm25Data = document.createElement("span");
            pm25Data.className = "medium";
            pm25Data.innerHTML = "PM2.5: " + this.textDataRecived.pm25 +"㎍/㎥";


            var co2Icon = document.createElement("tr");
		    if (this.textDataRecived.co2 <= 700) {
                Icon_co2 = "fa fa-smile-o";
                co2Icon.id = 'smile';
            }
            else if (this.textDataRecived.co2 > 700 && this.textDataRecived.co2 <= 1000) {
                Icon_co2 = "fa fa-meh-o"
                co2Icon.id = 'meh';
            }
            else {
                Icon_co2 = "fa fa-frown-o"
                co2Icon.id = 'frown';
            }
            co2Icon.className = Icon_co2;
            var co2Data = document. createElement("span");
            co2Data.className = "medium"
            co2Data.innerHTML = "CO2: " + this.textDataRecived.co2 + "ppm";

            table.appendChild(space1);
            table.appendChild(space2);
            table.appendChild(space3);

            space1.appendChild(pm10Icon);
            pm10Icon.appendChild(pm10Data);
            
            space2.appendChild(pm25Icon);
            pm25Icon.appendChild(pm25Data);

            space3.appendChild(co2Icon);
            co2Icon.appendChild(co2Data);
            
            wrapper.appendChild(table);
        }
        return wrapper;
    },
	
});
