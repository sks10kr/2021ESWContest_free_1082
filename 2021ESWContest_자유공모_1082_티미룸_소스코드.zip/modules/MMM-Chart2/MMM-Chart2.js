Module.register("MMM-Chart2", {
        defaults: {
            updateInterval: 3000,
            
        },

        getScripts: function () {
            return ["modules/" + this.name + "/node_modules/chart.js/dist/Chart.min.js"];
        },
    
        start: function () {
            // Log.info("Starting module: " + this.name);
            // requiresVersion: "2.1.0";
            // this.loaded = false
            // this.config = Object.assign({}, this.defaults, this.config);
            // Log.info("Starting module: " + this.name);

            this.scheduleUpdate();
            count = 0;
        },

        scheduleUpdate: function () {
            setInterval(() => {
                this.getData();
            }, 
            this.config.updateInterval);
            this.getData();
        },

        getData: function() {
            this.sendSocketNotification('GET_TEXT_DATA', this.config);
        },

        
    
        socketNotificationReceived: function(notification, payload) {
            if (notification === "TEXT_RESULT") {
                this.textDataRecived = payload;
                this.loaded = true;
            }

            
            if(count < 2) {
                this.updateDom();
                count = count + 1;
            }
            else {
                this.Chart_humid.data.datasets[0].data.push(this.textDataRecived.humid)
                data_length = this.Chart_humid.data.datasets[0].data;

                if (data_length.length > 10) {
                    this.Chart_humid.data.datasets[0].data.shift();
                }

                this.Chart_humid.data.labels.push(this.textDataRecived.time)
                labels_length = this.Chart_humid.data.labels;

                if (labels_length.length > 10) {
                    this.Chart_humid.data.labels.shift();
                }


                this.Chart_co2.data.datasets[0].data.push(this.textDataRecived.co2)
                data_length = this.Chart_co2.data.datasets[0].data;

                if (data_length.length > 10) {
                    this.Chart_co2.data.datasets[0].data.shift();
                }

                this.Chart_co2.data.labels.push(this.textDataRecived.time)
                labels_length = this.Chart_co2.data.labels;

                if (labels_length.length > 10) {
                    this.Chart_co2.data.labels.shift();
                }
                
                this.Chart_co2.update();
                this.Chart_humid.update();
            }
        },
    
        getDom: function () {  
            

            const wrapper = document.createElement("div");
            
            var table = document.createElement('td');
            var space1 = document.createElement('tr');
            var space2 = document.createElement('th');
            var space3 = document.createElement('th');

            this.ctx_co2= document.createElement("canvas");
            this.ctx_co2.style.width = "750px";
            this.ctx_co2.style.height = '750px';

            this.ctx_humid = document.createElement("canvas");
            this.ctx_humid.style.width = "750px";
            this.ctx_humid.style.height = '750px';
            
            wrapper.appendChild(table);
            table.appendChild(space1);
            space1.appendChild(space2);
            space1.appendChild(space3);
            space2.appendChild(this.ctx_humid);
            space3.appendChild(this.ctx_co2);

            this.Chart_co2 = new Chart(this.ctx_co2, {

                type: 'line',
                data: {
                    datasets: [{
                        data: [],

                        backgroundColor: 'rgba(255,255,255,0.3)',
                        borderColor: 'white',
                        borderWidth: 2,
                        
                        fill: true,
                    }]
                },
                options: {
                    title: {
                            display: true,
                            fontSize: 20,
                            fontColor: 'white',
                            text: '이산화탄소(ppm)',
                    },
                    legend: {
                        display: false
                    },
                    scales: {
                        xAxes: [{
                            ticks: {
                                fontSize: 15,
                                fontColor: 'white',
                                autoSkip: true,
                                maxTicksLimit: 10,
                            },
                            gridLines: {
                                color: 'rgba(255,255,255,0.2)',
                            },
                        }],

                        yAxes: [{
                            ticks: {
                                fontSize: 15,
                                fontColor: 'white',
                            },
                        }],
                    },
                }
            });
            
            this.Chart_humid = new Chart(this.ctx_humid, {

                type: 'line',
                data: {
                    datasets: [{
                        data: [],

                        backgroundColor: 'rgba(255,255,255,0.3)',
                        borderColor: 'white',
                        borderWidth: 2,
                        
                        fill: true,
                    }]
                },
                options: {
                    title: {
                            display: true,
                            fontSize: 20,
                            fontColor: 'white',
                            text: '습도(%)',
                    },
                    legend: {
                        display: false
                    },
                    scales: {
                        xAxes: [{
                            ticks: {
                                fontSize: 15,
                                fontColor: 'white',
                                autoSkip: true,
                                maxTicksLimit: 10,
                            },
                            gridLines: {
                                color: 'rgba(255,255,255,0.2)',
                            },
                        }],

                        yAxes: [{
                            ticks: {
                                fontSize: 15,
                                fontColor: 'white',
                            },
                        }],
                    },
                }
            });
            return wrapper;
        }
    });
        