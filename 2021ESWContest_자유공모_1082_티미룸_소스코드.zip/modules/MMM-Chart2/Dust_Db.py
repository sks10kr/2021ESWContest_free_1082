import firebase_admin
from firebase_admin import credentials
from firebase_admin import db
import json

#Firebase database 인증 및 앱 초기화
cred = credentials.Certificate('/home/pi/MagicMirror/modules/MMM-Chart2/myKey.json')
firebase_admin.initialize_app(cred,{
    'databaseURL' : 'https://help-airman-project-default-rtdb.firebaseio.com/'
})


ref = db.reference('in/CO2') #db 위치 지정
co2_data = ref.get()

ref = db.reference('in/hum') #db 위치 지정
humid_data = ref.get()

data = {
    "co2" : co2_data,
    "humid" : humid_data,
    }
    
data_json = json.dumps(data)
print (data_json)
