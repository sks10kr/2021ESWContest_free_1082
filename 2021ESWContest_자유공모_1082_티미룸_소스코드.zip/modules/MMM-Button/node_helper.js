var NodeHelper = require("node_helper");
var self;

module.exports = NodeHelper.create({

	start: function () {
        self = this;
        console.log("Starting node_helper for: " + this.name);
    },

	socketNotificationReceived: function(notification, payload) {
		if (notification === "ON") {
			console.log("ON MODE: ", payload);
			self.sendSocketNotification("ON_MODE: ", 1);
		}

		else if (notification === "OFF") {
			console.log("OFF MODE: ", payload);
			self.sendSocketNotification("OFF_MODE: ", 0);
		}
	},


});
