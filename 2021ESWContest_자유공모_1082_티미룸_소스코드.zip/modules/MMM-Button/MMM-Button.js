var mode = 0;

Module.register("MMM-Button", {
	defaults: {
		
	},

	requiresVersion: "2.1.0", // Required version of MagicMirror

	start: function() {
		var self = this;
		this.scheduleUpdate();
	},

	getStyles: function () {
		return [
			"MMM-Button.css",
		];
	},

	socketNotificationReceived: function (notification, payload) {
		if (notification === "AUTO_MODE: ") {
			mode = payload;
			this.loaded = true;
	   }
	   else if (notification === "MANUAL_MODE: ") {
		   mode = payload;
		   this.loaded =true;
	   }
	   else if (notification === "OPEN_MODE: ") {
			door = payload;
			this.loaded =true;
		}
	else if (notification === "CLOSE_MODE: ") {
			door = payload;
			this.loaded =true;
		}
	   this.updateDom();
	},

	getData: function() {
		
	},

	scheduleUpdate: function(delay) {
		var nextLoad = this.config.updateInterval;
		if (typeof delay !== "undefined" && delay >= 0) {
			nextLoad = delay;
		}
		nextLoad = nextLoad ;
		var self = this;
		setTimeout(function() {
			self.getData();
		}, nextLoad);
	},

	getDom: function() {

		var wrapper = document.createElement("div");

		var table = document.createElement("td");

		var space1 = document.createElement("tr");
		var space2 = document.createElement("tr");

		var modeButton = document.createElement("BUTTON");
        modeButton.innerHTML = "실내 공기 데이터";
        modeButton.addEventListener("click", () => this.buttonFunction1());
        modeButton.className = "demo2button"; //UI from css file
        wrapper.appendChild(modeButton);

		wrapper.appendChild(table);
		table.appendChild(space1);

		space1.appendChild(modeButton);
		
		return wrapper;
	},

	buttonFunction1: function()
	{
		if (mode == 0) {
			this.sendSocketNotification("ON", mode);

			Chart = MM.getModules().withClass('MMM-Chart');
			Chart[0].show(1000);

			Chart = MM.getModules().withClass('MMM-Chart2');
			Chart[0].show(1000);

			Dust = MM.getModules().withClass('MMM-Dust');
			Dust[0].hide(1000);

			DustInfo = MM.getModules().withClass('MMM-DustInfo');
			DustInfo[0].hide(1000);

			WeatherInfo = MM.getModules().withClass('MMM-WeatherInfo');
			WeatherInfo[0].hide(1000);

			Temp = MM.getModules().withClass('MMM-Temp');
			Temp[0].hide(1000);

			mode++;
			
		}
		else if (mode == 1) {
			this.sendSocketNotification("OFF", mode);
			
			Chart = MM.getModules().withClass('MMM-Chart');
			Chart[0].hide(1000);

			Chart = MM.getModules().withClass('MMM-Chart2');
			Chart[0].hide(1000);

			Dust = MM.getModules().withClass('MMM-Dust');
			Dust[0].show(1000);

			DustInfo = MM.getModules().withClass('MMM-DustInfo');
			DustInfo[0].show(1000);

			WeatherInfo = MM.getModules().withClass('MMM-WeatherInfo');
			WeatherInfo[0].show(1000);

			Temp = MM.getModules().withClass('MMM-Temp');
			Temp[0].show(1000);

			mode--;
		}
	},
});
